<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>七校联合办学作业网</title>

<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="wrap">
<!--head，放网站名文字和一定透明度的背景图片，该DIV右上角放登录-->
    <div id="head">
    <span><a href="index.html">七校联合办学作业网</a></span>
    <span>
    <span><a href="pages/login.html">
	
	<?php
@mysql_connect("localhost","root",'254916')
or die("数据库连接失败");
@mysql_select_db("完全不敢说话")
or die("选择数据库失败");
//获取输入的信息
$username = $_POST['username'];
$password = $_POST['password'];
//获取session的值
$sql = "select * from user where username = '$_POST[username]' and password = '$_POST[password]'";
$query = @mysql_query($sql)
or die("SQL语句执行失败");
//判断用户以及密码
if($row = mysql_fetch_array($query))
{
    //session_start();
	 $_SESSION['username'] = $row['username'];    
   echo '<p style="color:red;">';
echo "欢迎用户".$_SESSION['username'];
echo '<p/>';
}
?>
	
	</a></span>
    <span><a href="">联系我们</a></span>
    </span>
    </div>
    <div id="menu">
<!--选择专业和学校-->
    <form action="pages/publish.html">
          <select name="select_school" id="select_school" class="select">
              <option value="选择学校">--选择学校--</option>
              <option value="武汉大学">武汉大学</option>
              <option value="华中科技大学">华中科技大学</option>
              <option value="华中师范大学">华中师范大学</option>
              <option value="武汉理工大学">武汉理工大学</option>
              <option value="中南财经政法大学">中南财经政法大学</option>
              <option value="中国地质大学">中国地质大学</option>
              <option value="华中农业大学">华中农业大学</option>
          </select>
          <select name="select_major" id="select_major" class="select">
               <option value="选择专业">--选择专业--</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
               <option value="XX专业">XX专业</option>
          </select>
          
    
<!--menu-->
    <span>
       <ul>
           <li><a href="pages/inform.html">通知</a></li>
           <li><a href="pages/share.html">分享</a></li>
           <li><a href="pages/homework.html">作业</a></li>
           <li><a href="pages/support.html">解惑</a></li>
       </ul> 
    </span>
<!--查询&&信息发布-->
    <span><input class="btn" type="button" name="sub" value="查询" /></span>
    <span><a href="pages/publish.html">发布</a></span>
    </form>
    </div>
<!--slide according to school,each school for one picture-->
    <div id="slide_schools">
    <DIV id="idContainer2" class="container">
<TABLE id="idSlider2" border=0 cellSpacing=0 cellPadding=0>
  <TBODY>
<TR>
<TD class=td_f><A onclick="pgvSendClick({hottag:'ISD.SHOW.BANNER.SOFTMGR'});" href=""><IMG src="images/1.jpg"></A></TD>
<TD class=td_f><A onclick="pgvSendClick({hottag:'ISD.SHOW.BANNER.PY'});" href=""><IMG src="images/2.jpg" ></A></TD>
<TD class=td_f><A onclick="pgvSendClick({hottag:'ISD.SHOW.BANNER.PLAYER'});" href=""><IMG src="images/3.jpg"></A></TD>
<TD class=td_f><A onclick="pgvSendClick({hottag:'ISD.SHOW.BANNER.XF'});"  href=""><IMG src="images/4.jpg" ></A></TD>
</TR>
  </TBODY>
</TABLE>
<UL id=idNum class=num></UL>
</DIV>
    </div>
    <div id="mainbody">
        <table>
            <tbody>
                <tr>
                    <td>
                        <h3><a href="pages/inform.html">通知</a></h3>
                        <ul>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span></span><span class="btn">more</span></li>
                        </ul>
                    </td>
                    <td>
                        <h3><a href="pages/homework.html">作业</a></h3>
                        <ul>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span></span><span class="btn">more</span></li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h3><a href="pages/share.html">分享</a></h3>
                        <ul>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span></span><span class="btn">more</span></li>
                        </ul>
                    </td>
                    <td>
                        <h3><a href="pages/support.html">解惑</a></h3>
                        <ul>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span><a href="pages/detail.html">XXXXXXX</a></span><span>时间</span></li>
                            <li><span></span><span class="btn">more</span></li>
                        </ul>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="foot">
        <span>版权所有XXXXXXXXXX</span>
    </div>
</div>

<!--JS放在文件末尾载入解析，减少空白页面时间，提高用户体验-->
<script type="text/javascript" src="js/js.js"></script>



</body>
</html>