<?php
session_start();
?>
<?php
/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
//echo $_POST["question"];
//echo $_POST["answer"];
date_default_timezone_set("Asia/Shanghai");//设置时区为上海
$messagetime=date('Y-m-d H:i:s',time());//回帖时间
$title=$_POST["title"];
$publisheTime=$_POST["publishTime"];//发帖时间
$message=$_POST["message"];//回帖内容
$user=$_SESSION['username'];//回帖人（登入读帖的人）
//$q='qq';
//$a="a";
$con = @mysql_connect("localhost","root","254916");
if (!$con)
{
//die('Could not connect: ' . mysql_error());
echo 'Could not connect: ' . mysql_error();
}
mysql_select_db("diary",$con);
mysql_query("insert into message(title,publishTime,message,user,messageTime)values('$title','$publisheTime','$message','$user','$messagetime')");
mysql_close($con);
echo "$message<br>$messagetime<br>$user";
?>