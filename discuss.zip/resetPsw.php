<?php
session_start();
?>
<?php
$conn = @mysql_connect('localhost','root','254916');
mysql_query("use diary");//diary为database名
mysql_query("set names utf8");
$user=$_SESSION['username'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>发帖</title>
<style type="text/css">
body,h1,h2,h3,h4,h5,p,dl,dd,ul,ol,form,input,textarea,th,td,select { margin:0; padding:0; }
em { font-style:normal; }
li { list-style:none; }
a { text-decoration:none; }
img { border:none; vertical-align:top; }
table { border-collapse:collapse; }
input,textarea { outline:none; }
textarea { resize:none; overflow:auto; }
body { font-size:16px; font-family:"微软雅黑"; }
/*public*/
body{ width:1000px; height:auto; margin:0 auto; background: url(../img/login_bg.jpg) no-repeat center center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;}
/* end reset */
#wrap{ position:relative;}
#nav{width:1000px; height:40px; position:fixed; margin:0 auto; background-color:#CCF; z-index:3;}
#nav ul{ width: 350px; margin:0 auto; height:40px; }
#nav li{ cursor:pointer; float:left; color:red;/*后面给li添加实际内容时，需要根据lid的实际数量更改margin值*/ line-height:40px; height:40px; width:70px; text-align:center; }
#nav li:hover{
background:#FFF;
}

#main{ width:1000px; height:670px; position:relative; top:40px; background:#FFF;}
#main table{ margin:0 auto; text-align:center;}
#main form{ position:relative; top:230px;}
.fl{ text-align:left;}
.input{ text-indent:20px;  line-height:20px; height:20px;}
.btn{
width:40px;
float:right;
height:30px;
cursor:pointer;
margin:5px;
font-size:16px;
background: #66C1E4;
border: none;
color: #FFF;
box-shadow: 1px 1px 1px #4C6E91;
-webkit-box-shadow: 1px 1px 1px #4C6E91;
-moz-box-shadow: 1px 1px 1px #4C6E91;
text-shadow: 1px 1px 1px #5079A3;}
.btn:hover{
background: #3EB1DD;
}
</style>


<body>
 <div id="nav">
     <ul>
         <li><a href="showDiary.php">首页</a></li>
         <li><a href="diaryPublish.php">发帖</a></li>
         <li><a href="showMyDiary.php">我的帖子</a></li>
         <li><a href="resetPsw.php">修改密码</a></li>
         <li><a href="index.php?logout='logout'">注销</a></li>
     </ul>
 </div>
 <div id="wrap">
    <div id="main">
        <form name="resetPswForm" id="resetPswForm" action="resetPswSucceed.php" method="post">
          <table>
            <tbody>
              <tr>
                <td class="fl"><br /><span>请输入原密码：</span><br /></td>
                <td><br /><input class="input"  type="password" name="oriPsw" id="oriPsw"/><br /></td>
              <tr>
              <tr>
                <td class="fl"><br /><span>请输入新密码：</span><br /></td>
                <td><br /><input class="input" type="password" name="newPsw" id="newPsw"/><br /></td>
              </tr>
                <td class="fl"><br /><span>请再次输入新密码：</span><br /></td>
                <td><br /><input class="input" type="password" name="checkNewPsw" id="checkNewPsw"  /><br /></td>
              </tr>
              <tr>
                 <td></td>
                 <td><input class="btn" type="button" id="resetPsw" value="确认" /></td>
              </tr>
            </tbody>
          <table>
        </form>
      <!--修改密码-->
    </div>
    
 </div>
</body>
<!--JQ应在其他JS文件之前导入，否则无效-->
<script>
var resetPsw = document.getElementById("resetPsw");
resetPsw.onclick=function(){
	var form = document.getElementById("resetPswForm");
	if(checkForm(form)){//如果表单（返回true）合格
		form.submit();//提交表单给后台
		}
	}
//检测表单是否合格,这里的form只是一个形参，旧密码，新密码不能为空，且新密码要符合正则检验
function checkForm(form){
	   var oriPsw = document.getElementById("oriPsw");
	   var newPsw = document.getElementById("newPsw");
	   var checkNewPsw = document.getElementById("checkNewPsw");
	   //正则检验表单
	   if(oriPsw.value==''||newPsw.value==''||checkNewPsw==''){alert('旧密码，新密码不能为空！')}
	   var newPswRe = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,25}$/; //验证密码数字、字母、下划线
	   if(!newPswRe.test(newPsw.value)){alert('密码只能由6-25位数字、字母和下划线组成，且必须包含数字和字母');}
	   if(checkNewPsw.value!=newPsw.value){alert('两次输入的新密码不一致！');}
	   if(oriPsw.value!=''&&newPswRe.test(newPsw.value)&&checkNewPsw.value==newPsw.value){
		  return true;
		  }else {return false;}
	}
	
</script>

</html>
