<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
if($_GET['logout']){
	session_destroy();
	echo "<script>alert('已经退出登录');</script>";
	}
?>
<link href="css/myStyle.css" rel="stylesheet" type="text/css" />
<title>XX论坛</title>
<style>
p{  margin:10px;}
table{margin:10px;}
</style>
</head>
<body>
  <div class="wrap">
    <div id="head">
        <div class="cen">登录</div>
    </div>
    <div>
        <form action="login_succeed.php" method="POST">
            <p class="cen"><input type="text" name="username" id="user" /></p></br>
            <p class="cen"><input type="text" name="password" id="psw" /></p></br>
            <p class="cen" style="position:relative; top:-14px;"><input class="link" id="checkbox" type="checkbox" name="remeber" /><span class="link" >Remeber me?</span></p>
            <p class="cen link" style="position:relative; top:-14px;">Forget Username or Password?</p>
            <table>
              <tbody>
                <tr>
                  <td></td>
                  <td class="link"  style="background-color:rgb(91,128,32); border-radius:4px;position:relative; top:-14px; " onclick="check()">登录 </td>
                  <td></td>
                  <td class="link" style=";background-color:rgb(91,128,32); border-radius:4px;position:relative; top:-14px; "><a href="register.html">注册</a></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
        </form>
    </div>
  </div>
</body>
<script>
function check(){
var oForm = document.getElementsByTagName("form");
oForm[0].submit();}
</script>
</html>
