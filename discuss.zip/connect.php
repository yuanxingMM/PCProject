﻿<?php
$conn = @mysql_connect('localhost','root','254916');
mysql_query("use diary");//diary为database名
mysql_query("set names utf8");
?>