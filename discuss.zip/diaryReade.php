<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>读帖</title>
<link href="css/diaryReadeCss.css" rel="stylesheet" type="text/css" />
<?php
$username=$_SESSION['username'];//登入的用户名
$conn = @mysql_connect('localhost','root','254916');
mysql_query("use diary");//diary为database名
mysql_query("set names utf8");
$title=$_GET['title'];//获取showMyDiary传过来的title值
$user=$_GET['user'];//获取showMyDiary传过来user值(帖子作者)，区别于$username（此时正在读帖的人）
$time=$_GET['time'];//获取showMyDiary传过来的time值（帖子发表时间）
$sql = "select * from article where time='$time' and user='$user'";
$res = mysql_query($sql);
$rows = array();
while($row = mysql_fetch_assoc($res)){
	$rows[] = $row;
	}
?>
</head>

<body>
  <div id="nav">
     <ul>
     <!--
     心得：测试时发现无法点击到a链接，最后尝试在该行代码父级测试a链接是否有效，最后发现父级有效。此时想到层级覆盖问题。故当遇到点击无效时，试试修改层级z-index，当外层盖住内层时永远无法点击到内层
     -->
         <li><a href="showDiary.php">首页</a></li>
         <li><a href="diaryPublish.php">发帖</a></li>
         <li><a href="showMyDiary.php">我的帖子</a></li>
         <li><a href="resetPsw.php">修改密码</a></li>
         <li><a href="index.php?logout='logout'">注销</a></li>
     </ul>
     
 </div>
 <div id="wrap">
    <div id="main">
      <form name="insertMessageForm">
         <span>帖子标题</span><br />
         <p id="title"><?php echo $title; ?></p>
         <span>帖子分类</span><br />
         <p id="subject"><?php foreach($rows as $k=>$v){?>
            <?php echo $v['subject'];?>
            <?php }?></p>
         <p>帖子内容</p>
         <div class="fl">
         <div id="content">
          <?php foreach($rows as $k=>$v){?>
            <?php echo $v['content'];echo '<br> ';?>帖子作者：<span id="user"><?php echo $v['user'];?></span><?php echo '<br> ';?>发帖时间：<span id="time"><?php echo $v['time'];?></span>
            <?php }?>
             
             <input type="button" class="button" style="position:absolute; left:613px; top:492px;" value="删帖" onclick="deleteDiary()" />
         <textarea id="message" name="leaveMessage"></textarea><br />
         <input type="button" class="button" id="messageBtn" value="回帖" onclick="getValue()" />
      </form>
      </div></div>
      <div id="side" class="fr">
      <ul>
      <?php
	  $sql = "select * from message where title='$title'";//由帖子标题找到留言表中所有留言相关信息
      $res = mysql_query($sql);
      $rows = array();
      while($row = mysql_fetch_assoc($res)){
	  $rows[] = $row;
	  }
	  ?>
         <?php foreach($rows as $k=>$v){?>
            <li><?php echo$v['message'];echo '<br>';echo $v['messageTime'];echo '<br>';echo $v['user']; ?></li>
            <?php }?>
      </ul>
   </div></div>
    </div>
    </div>
 </div>
</body>
<!--JQ应在其他JS文件之前导入，否则无效-->
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>

<script type="text/javascript" src="js/diaryReadeJS.js"></script>


</html>
