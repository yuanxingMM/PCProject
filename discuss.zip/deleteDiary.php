<?php
session_start();
?>
<?php
/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
//echo $_POST["question"];
//echo $_POST["answer"];
$title=$_POST["title"];
$publishTime=$_POST["publishTime"];//发帖时间
$user=$_SESSION['username'];//登入删帖的人
$author=$_POST["user"];
//$q='qq';
//$a="a";
$con = @mysql_connect("localhost","root","254916");
if (!$con)
{
//die('Could not connect: ' . mysql_error());
echo 'Could not connect: ' . mysql_error();
}
if($user!=$author)
    {echo 'false';}
	else{
mysql_select_db("diary",$con);
//使用mysqli对象中的query()方法每次调用只能执行一条SQL命令。如果需要一次执行多条SQL命令，就必须使用mysqli对象中的 multi_query()方法。
mysql_query("delete from article where user='$author' and Time='$publishTime'");
mysql_query("delete from message where title='$title' and publishTime='$publishTime'");
mysql_close($con);
}
?>