<?php
session_start();
?>
<?php
/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
//echo $_POST["question"];
//echo $_POST["answer"];
date_default_timezone_set("Asia/Shanghai");//设置时区为上海
$time=date('Y-m-d H:i:s',time());
$title=$_POST["title"];
$subject=$_POST["subject"];
//PHP接收表单提交的信息之后存入数据库，再次从数据库获取数据再前端显示时，空格还有回车都消失了；
//解决办法：
//1，存入数据库时候进行替换   str_replace(" "," ",str_replace("\n","<br/>",$_POST['content']));  
//2，或者在取出数据之后进行替换 然后再在html中显示    echo nl2br($_POST['content']); //nl2br() 函数在字符串中的每个新行 (\n) 之前插入 HTML 换行符 (<br />)。  
str_replace(" "," ",str_replace("\n","<br/>",$_POST['content']));
$content=$_POST["content"];
$user=$_SESSION['username'];
//$q='qq';
//$a="a";
$con = @mysql_connect("localhost","root","254916");
if (!$con)
{
//die('Could not connect: ' . mysql_error());
echo 'Could not connect: ' . mysql_error();
}
mysql_select_db("diary",$con);
mysql_query("INSERT INTO article (title,content,subject,user,time) VALUES ('$title', '$content', '$subject','$user','$time')");
mysql_close($con);
echo "$title<br>subject:$subject<br>$time";
?>