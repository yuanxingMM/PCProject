﻿<?php
include 'connect.php';
//获取输入的信息
$username = $_POST['username'];
$password = $_POST['password'];
//获取session的值
$sql = "select * from user where username = '$_POST[username]' and password = '$_POST[password]'";
$query = @mysql_query($sql)
or die("SQL语句执行失败");
//判断用户以及密码
if($row = mysql_fetch_array($query))
{
    session_start();
	$_SESSION['username'] = $row['username'];
echo "登录成功,1秒后将自动跳转到主页面";
header("refresh:3;url=showMyDiary.php");	 
}
else{
	echo "用户名或密码错误，请重新输入！";
	header("refresh:3;url=index.php");
}



?>
	
