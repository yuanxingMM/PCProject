<?php
session_start();
?>
<?php
$conn = @mysql_connect('localhost','root','254916');
mysql_query("use diary");//diary为database名
mysql_query("set names utf8");
$user=$_SESSION['username'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>发帖</title>
<link href="css/diaryPublishCss.css" rel="stylesheet" type="text/css" />
</head>

<body>
 <div id="nav">
     <ul>
         <li><a href="showDiary.php">首页</a></li>
         <li><a href="diaryPublish.php">发帖</a></li>
         <li><a href="showMyDiary.php">我的帖子</a></li>
         <li><a href="resetPsw.php">修改密码</a></li>
         <li><a href="index.php?logout='logout'">注销</a></li>
     </ul>
 </div>
 <div id="wrap">
    <div id="main">
      <form name="insertDiaryForm">
         <span>帖子标题</span><br />
         <input id="title" name="title" type="text" /><br />
         <span>Subject</span><br />
         <select id="subject" name="subject">
         <option value="HTML">HTML</option>
         <option value="CSS">CSS</option>
         <option value="JavaScript">JavaScript</option>
         <option value="AJAX">AJAX</option>
         <option value="others">others</option>
         </select>
         <p>帖子内容</p>
         <div class="fl">
         <!--
          <textarea> 标签定义多行的文本输入控件。

文本区中可容纳无限数量的文本，其中的文本的默认字体是等宽字体（通常是 Courier）。

若果不作设置或不设定wrap，<textarea>和</textarea>之间的文字和符合、空格等都会被当作textarea的值，在html页面上展现出来。

为了避免<textarea>标签莫名多出来N多空格，<textarea>应该紧跟靠拢着写，即<textarea>这个中间不能有空格，不能换行</textarea>;
         例如：
         <textarea.....>   
   内容.....   
</textarea>  应该写成<textarea.....>内容.....</textarea> 
         -->
         <textarea name="content" id="content"></textarea><br />
         <input type="button" name="confirm" class="button" value="发帖" onclick="getValue()" />
         </div>
         </form>
         <div id="side" class="fr">
        <ul>
      <?php
	  $sql = "select * from article where user='$user'";//由帖子标题找到留言表中所有留言相关信息
      $res = mysql_query($sql);
      $rows = array();
      while($row = mysql_fetch_assoc($res)){
	  $rows[] = $row;
	  }
	  ?>
         <?php foreach($rows as $k=>$v){?>
            <li><?php echo$v['title'];echo '<br>';echo $v['time']?></li>
            <?php }?>
      </ul>
   </div>
    </div>
    
 </div>
</body>
<!--JQ应在其他JS文件之前导入，否则无效-->
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/diaryPublishJS.js"></script>

</html>
