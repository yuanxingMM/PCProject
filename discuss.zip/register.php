﻿<?php
session_start();
?>
<?php
include 'connect.php';
//获取输入的信息
$username = $_POST['username'];
$password = $_POST['password'];
$mail = $_POST['mail'];
//获取session的值
$sql = "insert into user(username,password,mail)values('$username','$password','$mail')";
$query = @mysql_query($sql)
or die("SQL语句执行失败");
	$_SESSION['username'] = $username;
echo "注册成功,3秒后将自动跳转到主页面";
header("refresh:3;url=showDiary.php");	 





?>
	
