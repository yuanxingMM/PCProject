﻿create table article
(
title varchar(100) NOT NULL,
content varchar(2000) NOT NULL,
subject varchar(40) NOT NULL,
user varchar(50) NOT NULL,
time varchar(50) NOT NULL,
primary key(user,time)
);
create table message
(
title varchar(40) NOT NULL,
publishTime varchar(100) NOT NULL,
message varchar(200) NOT NULL,
USER varchar(20) NOT NULL,
messageTime varchar(100) NOT NULL,
primary key(user,messageTime)
);
create table user(
username varchar(50) NOT NULL primary key,
password varchar(50) NOT NULL,
mail varchar(50) NOT NULL
);