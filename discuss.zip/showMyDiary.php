<?php
session_start();
?>
<?php
header("Content-type:text/html;charset=utf-8");
$username=$_SESSION['username'];
$page = isset($_GET['page'])?$_GET['page']:1;
$pagesize = 10;//每页显示条目数量
$offset = ($page-1)*$pagesize;
$conn = @mysql_connect('localhost','root','254916');
mysql_query("use diary");//diary为database名
mysql_query("set names utf8");
$max_sql = "select * from article where user='$username'";//article为table名.31行的title为table中某一项（列）的列名
$resu = mysql_query($max_sql);
$total = @mysql_num_rows($resu);
$pagemax = ceil($total/$pagesize);
$sql = "select * from article where user='$username' limit $offset,$pagesize";
$res = mysql_query($sql);
$rows = array();
while($row = mysql_fetch_assoc($res)){
	$rows[] = $row;
	}
//var_dump($rows);打印
?>

<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>我的帖子</title>

<link href="css/showDiary.css" rel="stylesheet" type="text/css">
</head>
<body>
   <div id="nav">
        <ul>
         <li><a href="showDiary.php">首页</a></li>
         <li><a href="diaryPublish.php">发帖</a></li>
         <li><a href="showMyDiary.php">我的帖子</a></li>
         <li><a href="resetPsw.php">修改密码</a></li>
         <li><a href="index.php?logout='logout'">注销</a></li>
     </ul>
   </div>
   <div id="content">
        <ul>
            <!--传值title给diaryReade.php页面，然后在diaryReade.php页面$_GET['title']获取传递的值title，最后根据title的值查找帖子，从而显示帖子相关信息-->
            <!--后期再在这里实现批量删除帖子的功能-->
            <?php foreach($rows as $k=>$v){?>
            <li><a href="diaryReade.php?user=<?php echo$v['user']; ?>&title=<?php echo$v['title']; ?>&time=<?php echo$v['time']; ?>"><?php echo $v['title'];echo ' ';echo $v['time'];?></a></li>
            <?php }?>
        </ul>
    </div>
    <div id="pageList">
        <a class="button" href="showMyDiary.php?page=1">首页</a>
        <a class="button" href="showMyDiary.php?page=<?php echo $page<=1?1:$page-1;?>">上一页</a>
        <a class="button" href="showMyDiary.php?page=<?php echo $page>=$pagemax?$pagemax:$page+1?>">下一页</a>
        <a class="button" href="showMyDiary.php?page=<?php echo $pagemax?>">末页</a>
    </div>
</body>
<script type="text/javascript" src="js/showDiary.js"></script>

</html>