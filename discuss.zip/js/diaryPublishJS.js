/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/
//在成功发帖后清空当前页内容，避免点击按钮过快造成重复提交
function clearValue(){
	var titleClear =document.getElementById("title");
	var subjectClear =document.getElementById("subject");
	var contentClear =document.getElementById("content");
	titleClear.value='';
	subjectClear.value='';
	contentClear.value='';
	}
var xmlHttp;
function getValue(){
var title =document.insertDiaryForm.title.value;
var subject =document.insertDiaryForm.subject.value;
var content =document.insertDiaryForm.content.value;
//alert("getvaluel");

// alert(question);

submit(title,subject,content);
};
function submit(title,subject,content){
xmlHttp=GetXmlHttpObject();
if (xmlHttp==null)
{
alert ("Your browser does not support AJAX!");
return;
}
xmlHttp.onreadystatechange =function(){
if(xmlHttp.readyState ==4){

//alert(xmlHttp.responseText);
clearValue();//清空当前编辑页的帖子内容
//$('#side ul').append($li);将新创建的li节点插入到ul容器的内容底部
//这里无刷新更新当前登入用户发帖后右边side的帖子列表，折腾半天，最后发现这里用了JQ而没有导入JQ文件
var $li = '<li>'+xmlHttp.responseText+'<li>';
$('#side ul').prepend($li); //将新创建的div节点插入到nav容器的内容顶部


}
};
var url = "insertDiary.php";
xmlHttp.open("post",url,true);
xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");
xmlHttp.send("title="+title+"&subject="+subject+"&content="+content);

}
function GetXmlHttpObject()
{
var xmlHttp=null;
try
{
// Firefox, Opera 8.0+, Safari
xmlHttp=new XMLHttpRequest();
}
catch (e)
{
// Internet Explorer
try
{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
}
catch (e)
{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
}
return xmlHttp;
}