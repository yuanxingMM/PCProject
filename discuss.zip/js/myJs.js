// JavaScript Document
//文档说明，每个封装函数第一行为函数的作用说明，最后一行为函数应用举例，最后一个}之前为该封装函数的一些说明和讲解
//获取对象在HTML页面中的绝对位置坐标（x,y）
function getPos(obj){
	var pos = {left:0,top:0};//json
	while (obj){
		pos.left+=obj.offsetLeft;
		pos.top+=obj.offsetTop;
		obj=obj.offsetParent;
		}	
		return pos;
	}
	//eg:  alert(getPos(obj).top[left]);
//给元素添加class  addClass(obj,'className');
function addClass(obj,className){
	//如果object原来没有class
	if(obj.className ==''){
		obj.className = className;
	} else {
		//如果原来有class
		var arrClassName = obj.className.split('');
		var _index = arrIndexOf(arrClassName,className);
		if(_index==-1){
			//如果要添加的class在原来的class中不存在
			obj.className +=''+ className;
		}else{
		//如果要添加的class在原来的class中存在,不需要进行任何运算
		}
	}
}
//查找数组arr中是否存在v，如果有，返回v的index，如果没有，返回-1
function arrIndexOf(arr,v){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==v){
			return i;
		}
	}
	return -1;
	//移除元素的class  remove(obj,'className');
//注意''和' '是有区别的' '表示空格字符串，封装本函数时，''程序不会报错，但运行不出来结果
}

function removeClass(obj,className){
	//如果原来没有class，不需要进行任何操作(没有class，不需要移除)
	if(obj.className!=''){
		//如果原来的obj有class
		var arrClassName = obj.className.split(' ');//此处className为属性，不是参数className
		var _index = arrIndexOf(arrClassName,className);//判断原来的obj中是否存在要移除的class
		if(_index!=-1){
			//如果有要移除的class
			arrClassName.splice(_index,1);//删除 class
			obj.className = arrClassName.join(' ');//用空格将数组拼接成字符串
		}
	}
}

//事件绑定的兼容性封装2017/7/6
function bind(obj,evname,fn){
	if(obj.addEventListener){//标准浏览器
		obj.addEventListener(evname,fn,false);//false表示不捕获允许冒泡（即），默认值也为false
		}else{//IE
			obj.attachEvent('on'+evname,function(){//addEventListener与attachEvent的区别之一是事件名称有无on，此处需进行字符串拼接
				fn.call(obj);//fn.call()与fn()唯一不同的是call可以改变函数执行时内部this的指向，此处将this指向改为obj
				            //call方法第一个参数改变this指向，从第二个参数开始就是原来函数的参数列表
				})
			}
//关于addEventListener的true，false
//事件发生后，先进后出，参数为true时，检测进的事件，参数为false时，检测出的事件
//
//两种事件绑定方法attachEvent、addEventListener及兼容性处理，用addEventListener绑定的事件要用preventDefault()阻止默认行为
	//document.onclick = fn1;
//document.onclick = fn2;	//会覆盖前面绑定fn1

//给一个对象的同一个事件绑定多个不同的函数
//给一个元素绑定事件函数的第二种形式

/*
ie：obj.attachEvent(事件名称，事件函数);
	1.没有捕获
	2.事件名称有on
	3.事件函数执行的顺序：标准ie-》正序   非标准ie-》倒序
	4.this指向window
标准：obj.addEventListener(事件名称，事件函数，是否捕获);
	1.有捕获
	2.事件名称没有on
	3.事件执行的顺序是正序
	4.this触发该事件的对象
*/

/*document.attachEvent('onclick', function() {
	fn1.call(document);
});
document.attachEvent('onclick', fn2);*/

//是否捕获 : 默认是false    false:冒泡 true：捕获

/*document.addEventListener('click', fn1, false);
document.addEventListener('click', fn2, false);*/
	}
//eg:  bind(document,'click',fn1);

function drag(obj){
	obj.onmousedown=function(ev){//按下鼠标
		var ev=ev||event;//兼容
		var disX = ev.clientX-this.offsetLeft;
		var disY = ev.clientY-this.offsetTop;
		if(obj.setCapture){//非标准IE
			obj.setCapture();//全局捕获阻止拖拽默认行为
		}
		document.onmousemove=function(){//onmousemove在onmouseown里面，表示按下鼠标不松开并且移动鼠标位置
			var ev = ev||event;
			obj.style.left = ev.clientX-disX+'px';
			obj.style.top = ev.clientY-disY+'px';
		}
		document.onmouseup=function(){//松开鼠标
			document.onmousemove=document.onmouseup=null;//事件置空
			if(obj.releaseCapture){
				obj.releaseCapture();//释放非标准IE下的全局捕获
			}
		}
		return false;//阻止标准浏览器下拖拽的默认行为
	}
//注意：凡是涉及到移动元素（对象）在页面中的位置（X,Y），该元素（对象）能动移动的前提是它设置了定位（position），
//否则无法移动
}
//eg: var oDiv=document.getElementById("div1"); drag(oDiv);
//cookie封装2017/7/8
//1.设置cookie 设置cookie时最好进行编码(可以直接封装在函数里面)，这样可以处理一些特殊字符串  eg: SetCookie('username',username.value,5);
function setCookie(key,value,t){//时间t的单位为天
	var oDate = new Date();//new 一个Date对象
	oDate.setDate(oDate.getDate()+t);//给new的对象赋值为当前服务器时间
	document.cookie = key+'='encodeURI(value)+';expires='oDate.toGMTString();//时间t必须为字符串格式，（obj.toString），时间对象将对象转换为字符串的特殊方法toGMTString
}
//2.获取单独的cookie
function getCookie(){
	var arr1 = document.cookie.split(';');//;后面必须跟一个空格？
	for(var i = 0;i<arr1.length;i++){
		var arr2 = arr[i].split('=');
		if(arr2[0])==key{
			return decodeURI(arr2[1]);
		}
	}
}
//3.删除cookie
//获取obj的attr，兼容性好  eg:getStyle(oDiv,'width' );
function getStyle(obj,attr){
	if(obj.currentStyle){//低版本IE
		return obj.currentStyle[attr];
	}
	else{//标准浏览器
		return getComputedStyle(obj,false)[attr];
	}
//该封装函数中的if分支也可以改成三目运算
//return obj.currentStyle?obj.currentStyle[attr]:getComputedStyle(obj)[attr];
//调用时，obj和attr之中除了逗号之外，不要留有空格
//使用getStyle的好处是可以用JS获取非内嵌样式,若直接用obj.style[attr],则只能获取非内嵌样式
//1.style.width 样式宽
//2.clientWidth 可视区宽（style.width+padding）
//3.offsetWidth（兼容性差，很容易出问题，尽量避免使用） 占位宽（clientWidth_border）

// 2017/7/8用json可以达到设置一个参数即可同时改变多个attr的目的（一个参数传多个attr）
}

function setStyle(obj,json){
	var attr='';
	for(attr in json){
		obj.style[attr]=json[attr];
	}
	//eg setStyle(oDiv,{width:'200px',height:'200px',background:'green'});
//json和Array非常相似，不同的是json用字符串作为下标，Array用数字作为下标，json只能用for...in遍历，且一旦遍历开始就会遍历整个json
//Array既可以用for...in又可以用普通的for循环，并且可以控制遍历范围
//？？？？obj[attr] 表示obj不确定的attr，obj.attr表示obj某个确定的attr
//遍历json for(i in json){alert(obj[i]);} i为字符串
}

//完美运动框架  ???
function startMove(obj, json, fnEnd)
{
    clearInterval(obj.timer);
    obj.timer=setInterval(function (){
        var bStop=true;        //假设：所有值都已经到了
        
        for(var attr in json)
        {
            var cur=0;
            
            if(attr=='opacity')
            {
                cur=Math.round(parseFloat(getStyle(obj, attr))*100);
            }
            else
            {
                cur=parseInt(getStyle(obj, attr));
            }
            
            var speed=(json[attr]-cur)/6;
            speed=speed>0?Math.ceil(speed):Math.floor(speed);
            
            if(cur!=json[attr])
                bStop=false;
            
            if(attr=='opacity')
            {
                obj.style.filter='alpha(opacity:'+(cur+speed)+')';
                obj.style.opacity=(cur+speed)/100;
            }
            else
            {
                obj.style[attr]=cur+speed+'px';
            }
        }
        
        if(bStop)
        {
            clearInterval(obj.timer);
                        
            if(fnEnd)fnEnd();
        }
    }, 30);
}












































