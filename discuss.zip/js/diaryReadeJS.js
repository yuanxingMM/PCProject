/*
* To change this template, choose Tools | Templates
* and open the template in the editor.
*/

var xmlHttp;
function getValue(){
//alert("getvaluel");
//获取form表单input输入后的值，用.value；
//获取标签内已经存在的文本值，用innerHTML获取，此时用value无法获取
var title =document.getElementById("title").innerHTML;
var publishTime =document.getElementById("time").innerHTML;
var message =document.insertMessageForm.leaveMessage.value;
// alert(question);

submit(title,publishTime,message);
};
function submit(title,publishTime,message){
xmlHttp=GetXmlHttpObject();
if (xmlHttp==null)
{
alert ("Your browser does not support AJAX!");
return;
}
xmlHttp.onreadystatechange =function(){
if(xmlHttp.readyState ==4){
//alert(xmlHttp.responseText);

//$('#side ul').append($li);将新创建的li节点插入到ul容器的内容底部
var $li = '<li>'+xmlHttp.responseText+'<li>';
$('#side ul').prepend($li); //将新创建的div节点插入到nav容器的内容顶部

}
};
var url = "leaveMessage.php";
xmlHttp.open("post",url,true);
xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");
xmlHttp.send("title="+title+"&publishTime="+publishTime+"&message="+message);

}
function GetXmlHttpObject()
{
var xmlHttp=null;
try
{
// Firefox, Opera 8.0+, Safari
xmlHttp=new XMLHttpRequest();
}
catch (e)
{
// Internet Explorer
try
{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
}
catch (e)
{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
}
return xmlHttp;
}





//删帖
function deleteDiary(){

var title =document.getElementById("title").innerHTML;//帖子标题
var user =document.getElementById("user").innerHTML;//作者名字
var publishTime =document.getElementById("time").innerHTML;//帖子发表时间
// alert(question);
subt(title,publishTime,user);
}
//提交数据给后台验证，若是帖子作者，执行删帖，否则提示不是帖子作者，不能删贴
function subt(title,publishTime,user){
xmlHttp=GetXmlHttpObject();
if (xmlHttp==null)
{
alert ("Your browser does not support AJAX!");
return;
}
xmlHttp.onreadystatechange =function(){
if(xmlHttp.readyState ==4){
var content=document.getElementById("content");
var side=document.getElementById("side");
var title=document.getElementById("title");
var subject=document.getElementById("subject");
//alert(xmlHttp.responseText);
if(xmlHttp.responseText=='false')//注意=是赋值，==是值相等，===是值和数据类型也相等，这里刚开始只用了一个=，测试了大半天才发现问题
  {alert("您不是帖子作者，无权删除该贴！");}
  else{
alert("删帖成功！");
content.innerHTML='';
side.innerHTML='';
title.innerHTML='';
subject.innerHTML='';}
}
};
var url = "deleteDiary.php";
xmlHttp.open("post",url,true);
xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");
xmlHttp.send("title="+title+"&publishTime="+publishTime+"&user="+user);

}
function GetXmlHttpObject()
{
var xmlHttp=null;
try
{
// Firefox, Opera 8.0+, Safari
xmlHttp=new XMLHttpRequest();
}
catch (e)
{
// Internet Explorer
try
{
xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
}
catch (e)
{
xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
}
}
return xmlHttp;
}
