﻿<?php
session_start();
?>
<?php
$user=$_SESSION['username'];//当前登入用户名
$oriPsw=$_POST["oriPsw"];
$newPsw=$_POST["newPsw"];
$con = @mysql_connect("localhost","root","254916");
mysql_select_db("diary",$con);
if(!$con){
	echo 'Could not connect: ' . mysql_error();
	}
if ($con)
{
	$sql = "select * from user where username = '$user' and password = '$oriPsw'";
	$query = @mysql_query($sql)
	or die("SQL语句执行失败");
	if($row = mysql_fetch_array($query)){
		@mysql_query("UPDATE user SET password = '$newPsw' WHERE username = '$user';");
		echo '密码修改成功';
		header("refresh:3;url=showDiary.php");
		}else{
			header("refresh:3;url=resetPsw.php");
			echo '原密码错误，密码修改失败！';
			}
//换一种思路，之前一直在考虑比较输入的原密码与数据库中的记录密码是否一致，最后一致无法由session的用户名取到对应密码，
//之后考虑到根据用户名和密码在user表中进行进行sql查询，若能进行查询，表明用户名和密码是对应的mysql_query($sql)返回true，否则返回false
//根据返回值执行update操作，若返回true，执行，否则，不执行，并提示用户原密码错误
//die('Could not connect: ' . mysql_error());
}
//echo $sqlPsw
//结果
//Resource id #4 这个不是错误。而是你直接把数据库的查询结果打印出来所致。
//需要用mysql_fatch_array把查询结果遍历并取出数据放到数组或者是变量中才行。
mysql_close($con);
?>
